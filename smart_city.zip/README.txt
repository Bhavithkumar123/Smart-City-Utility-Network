SMART CITY UTILITY NETWORK — WEB PROTOTYPE

RUN IT
1. Extract Smart_City_Utility_Network_Web_Prototype.zip.
2. Open the extracted folder.
3. Double-click index.html in a modern browser.
4. No server or package installation is required.

FEATURES
- Interactive sample network of seven city zones.
- Electricity, water and road service indicators.
- Click zones to inspect population and service gaps.
- Connected components with depth-first search.
- Minimum spanning tree/forest with Kruskal's algorithm.
- Shortest path with Dijkstra's algorithm.
- Vulnerability ranking based on service gaps and population.

NOTE
The network and costs are illustrative demo data, not live GIS or real construction costs.
